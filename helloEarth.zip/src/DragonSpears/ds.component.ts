import { Component, Input, OnInit, OnChanges } from '@angular/core';

@Component({
  selector: 'ds',
  templateUrl: './ds.component.html',
  styleUrls: ['./ds.component.css']
})
export class DSComponent implements OnInit, OnChanges {
  title = 'Welcome to DragonSpears Angular Guide (I am part of the DSComponent)';
  @Input() name: string;
  type: string;
  constructor(){
    this.type = 'info';
    this.name = '';
  }

  ngOnInit(){
  }

  ngOnChanges() {
    this.type = this.name === 'clicked'?'info':'success';
  }
}
