import { Component } from '@angular/core';
import { SharedService } from '../shared/shared.service';
import {AppService} from '../app.service'

@Component({
  selector: 'ds-route-0',
  template: `{{title}}{{name}}<br/>
             <button class="btn btn-small btn-secondary"><a routerLink="" routerLinkActive="active">Go back Home</a></button>`,
  styleUrls: ['./ds.component.css']
})
export class DSRoute0Component {
  title = 'I am the second component, part of the DSModule.Looks like you have set the input to:';
  name = '';
  constructor(private sharedService: AppService){
    sharedService.nameUpdated$.subscribe(updatedName => {
      this.name = updatedName;
    },
    error => {
      console.log(error);
    });
  }
}
