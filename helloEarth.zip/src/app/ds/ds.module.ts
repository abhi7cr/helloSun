import { NgModule } from '@angular/core';

import { DSComponent } from './ds.component';
import { DSRoute0Component } from './ds-route-0.component';

import { SharedModule } from '../shared/shared.module';
import { DSRoutingModule } from './ds-routing.module';

@NgModule({
  declarations: [
    DSComponent,
    DSRoute0Component
  ],
  imports: [
    SharedModule,
    DSRoutingModule
  ],
  exports: [
    DSComponent,
    DSRoute0Component
  ],
  providers: [],
})
export class DSModule { }
