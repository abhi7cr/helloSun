import { NgModule }            from '@angular/core';
import { Routes, RouterModule }        from '@angular/router';

import { DSComponent }  from './ds.component';
import { DSRoute0Component }  from './ds-route-0.component';

const routes: Routes = [
  { path: '', component: DSComponent },
  { path: ':id', component: DSRoute0Component }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DSRoutingModule {}
